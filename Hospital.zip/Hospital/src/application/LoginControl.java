package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginControl {
	Connection con;
	Main object = new Main();
	@FXML
	private TextField Username;
	@FXML
	private PasswordField Password;
	@FXML
	private Button Login;
	@FXML
	public void initialize(){
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hospital","root","v");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	@FXML
	public void login(){
		try{  
			
			PreparedStatement stmt=con.prepareStatement("select * from Login_Accounts where Username=? and Password=?");  
			stmt.setString(1, Username.getText());
			stmt.setString(2, Password.getText());
			ResultSet rs=stmt.executeQuery(); 
			//Statement stmt=con.createStatement();  
			//ResultSet rs=stmt.executeQuery("select * from Login_Accounts where Username="+Username.getText());  
			  
			if(rs.next()){
				object.welcome();
			}
				
			//System.out.println(rs.getString(1)+"  "+rs.getString(2));  
			  
			//con.close();  
			  
			}catch(Exception e){ System.out.println(e);} 
	}
	
	public void control(Main object){
		this.object=object;
	}
}

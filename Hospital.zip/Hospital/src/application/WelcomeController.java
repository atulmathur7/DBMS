package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class WelcomeController {
	
	Connection con;
	
	
	@FXML
	private TextField DeleteDoctorID;
	@FXML
	private Label RoomAvailable;
	@FXML
	private Label AppointmentAvailable;
	@FXML
	private TextField AppointmentTime;
	@FXML
	private Label Diagnosis;
	@FXML
	private TextField AdmitDiseaseID;
	@FXML
	private TextField AppointmentPatientID;
	@FXML
	private TextField AppointmentDoctorFname;
	@FXML
	private TextField AppointmentDoctorLname;
	@FXML
	private TextField AppointmentSpeciality;
	@FXML
	private TextField AppointmentBookDoctorID;
	@FXML
	private TextField AppointmentCancelDoctorID;
	@FXML
	private Button AppointmentSubmit;
	@FXML
	private Button AppointmentBook;
	@FXML
	private Button AppointmentCancel;
	@FXML
	private TextField AdmitPatientID;
	@FXML
	private TextField AdmitAvailableFname;
	@FXML
	private TextField AdmitAvailableLname;
	@FXML
	private TextField AdmitAvailableSpeciality;
	@FXML
	private TextField AdmitAvailableRoomType;
	@FXML
	private TextField AdmitFname;
	@FXML
	private TextField AdmitLname;
	@FXML
	private TextField AdmitSpeciality;
	@FXML
	private TextField AdmitRoomType;
	@FXML
	private TextField DischargeAdmissionID;
	@FXML
	private Button AdmitCheck;
	@FXML
	private Button Admit;
	@FXML
	private Button Discharge;
	@FXML
	private TextField PatientExistingPatientID;
	@FXML
	private TextField PatientExistingContactNo;
	@FXML
	private TextField PatientNewFname;
	@FXML
	private TextField PatientNewLname;
	@FXML
	private TextField PatientNewAddress;
	@FXML
	private TextField PatientNewDOB;
	@FXML
	private TextField PatientNewContactNumber;
	@FXML
	private Button PatientNew;
	@FXML
	private Button PatientExisting;
	@FXML
	private TextField DiagnosisDisease;
	@FXML
	private Button DiagnosisSubmit;
	@FXML
	private TextField EnquiryPatientID;
	@FXML
	private Label EnquiryLabel;
	
	
	
	public TextField getAppointmentPatientID() {
		return AppointmentPatientID;
	}
	public void setAppointmentPatientID(TextField appointmentPatientID) {
		AppointmentPatientID = appointmentPatientID;
	}
	public TextField getAppointmentDoctorFname() {
		return AppointmentDoctorFname;
	}
	public void setAppointmentDoctorFname(TextField appointmentDoctorFname) {
		AppointmentDoctorFname = appointmentDoctorFname;
	}
	public TextField getAppointmentDoctorLname() {
		return AppointmentDoctorLname;
	}
	public void setAppointmentDoctorLname(TextField appointmentDoctorLname) {
		AppointmentDoctorLname = appointmentDoctorLname;
	}
	public TextField getAppointmentSpeciality() {
		return AppointmentSpeciality;
	}
	public void setAppointmentSpeciality(TextField appointmentSpeciality) {
		AppointmentSpeciality = appointmentSpeciality;
	}
	public TextField getAppointmentBookDoctorID() {
		return AppointmentBookDoctorID;
	}
	public void setAppointmentBookDoctorID(TextField appointmentBookDoctorID) {
		AppointmentBookDoctorID = appointmentBookDoctorID;
	}
	public TextField getAppointmentCancelDoctorID() {
		return AppointmentCancelDoctorID;
	}
	public void setAppointmentCancelDoctorID(TextField appointmentCancelDoctorID) {
		AppointmentCancelDoctorID = appointmentCancelDoctorID;
	}
	public Button getAppointmentSubmit() {
		return AppointmentSubmit;
	}
	public void setAppointmentSubmit(Button appointmentSubmit) {
		AppointmentSubmit = appointmentSubmit;
	}
	public Button getAppointmentBook() {
		return AppointmentBook;
	}
	public void setAppointmentBook(Button appointmentBook) {
		AppointmentBook = appointmentBook;
	}
	public Button getAppointmentCancel() {
		return AppointmentCancel;
	}
	public void setAppointmentCancel(Button appointmentCancel) {
		AppointmentCancel = appointmentCancel;
	}
	public TextField getAdmitPatientID() {
		return AdmitPatientID;
	}
	public void setAdmitPatientID(TextField admitPatientID) {
		AdmitPatientID = admitPatientID;
	}
	public TextField getAdmitAvailableFname() {
		return AdmitAvailableFname;
	}
	public void setAdmitAvailableFname(TextField admitAvailableFname) {
		AdmitAvailableFname = admitAvailableFname;
	}
	public TextField getAdmitAvailableLname() {
		return AdmitAvailableLname;
	}
	public void setAdmitAvailableLname(TextField admitAvailableLname) {
		AdmitAvailableLname = admitAvailableLname;
	}
	public TextField getAdmitAvailableSpeciality() {
		return AdmitAvailableSpeciality;
	}
	public void setAdmitAvailableSpeciality(TextField admitAvailableSpeciality) {
		AdmitAvailableSpeciality = admitAvailableSpeciality;
	}
	public TextField getAdmitAvailableRoomType() {
		return AdmitAvailableRoomType;
	}
	public void setAdmitAvailableRoomType(TextField admitAvailableRoomType) {
		AdmitAvailableRoomType = admitAvailableRoomType;
	}
	public TextField getAdmitFname() {
		return AdmitFname;
	}
	public void setAdmitFname(TextField admitFname) {
		AdmitFname = admitFname;
	}
	public TextField getAdmitLname() {
		return AdmitLname;
	}
	public void setAdmitLname(TextField admitLname) {
		AdmitLname = admitLname;
	}
	public TextField getAdmitSpeciality() {
		return AdmitSpeciality;
	}
	public void setAdmitSpeciality(TextField admitSpeciality) {
		AdmitSpeciality = admitSpeciality;
	}
	public TextField getAdmitRoomType() {
		return AdmitRoomType;
	}
	public void setAdmitRoomType(TextField admitRoomType) {
		AdmitRoomType = admitRoomType;
	}
	public TextField getDischargeAdmissionID() {
		return DischargeAdmissionID;
	}
	public void setDischargeAdmissionID(TextField dischargeAdmissionID) {
		DischargeAdmissionID = dischargeAdmissionID;
	}
	public Button getAdmitCheck() {
		return AdmitCheck;
	}
	public void setAdmitCheck(Button admitCheck) {
		AdmitCheck = admitCheck;
	}
	public Button getAdmit() {
		return Admit;
	}
	public void setAdmit(Button admit) {
		Admit = admit;
	}
	public Button getDischarge() {
		return Discharge;
	}
	public void setDischarge(Button discharge) {
		Discharge = discharge;
	}
	public TextField getPatientExistingPatientID() {
		return PatientExistingPatientID;
	}
	public void setPatientExistingPatientID(TextField patientExistingPatientID) {
		PatientExistingPatientID = patientExistingPatientID;
	}
	public TextField getPatientExistingContactNo() {
		return PatientExistingContactNo;
	}
	public void setPatientExistingContactNo(TextField patientExistingContactNo) {
		PatientExistingContactNo = patientExistingContactNo;
	}
	public TextField getPatientNewFname() {
		return PatientNewFname;
	}
	public void setPatientNewFname(TextField patientNewFname) {
		PatientNewFname = patientNewFname;
	}
	public TextField getPatientNewLname() {
		return PatientNewLname;
	}
	public void setPatientNewLname(TextField patientNewLname) {
		PatientNewLname = patientNewLname;
	}
	public TextField getPatientNewAddress() {
		return PatientNewAddress;
	}
	public void setPatientNewAddress(TextField patientNewAddress) {
		PatientNewAddress = patientNewAddress;
	}
	public TextField getPatientNewDOB() {
		return PatientNewDOB;
	}
	public void setPatientNewDOB(TextField patientNewDOB) {
		PatientNewDOB = patientNewDOB;
	}
	public TextField getPatientNewContactNumber() {
		return PatientNewContactNumber;
	}
	public void setPatientNewContactNumber(TextField patientNewContactNumber) {
		PatientNewContactNumber = patientNewContactNumber;
	}
	public Button getPatientNew() {
		return PatientNew;
	}
	public void setPatientNew(Button patientNew) {
		PatientNew = patientNew;
	}
	public Button getPatientExisting() {
		return PatientExisting;
	}
	public void setPatientExisting(Button patientExisting) {
		PatientExisting = patientExisting;
	}
	public TextField getDiagnosisDisease() {
		return DiagnosisDisease;
	}
	public void setDiagnosisDisease(TextField diagnosisDisease) {
		DiagnosisDisease = diagnosisDisease;
	}
	public Button getDiagnosisSubmit() {
		return DiagnosisSubmit;
	}
	public void setDiagnosisSubmit(Button diagnosisSubmit) {
		DiagnosisSubmit = diagnosisSubmit;
	}
	
	
	@FXML
	public void initialize(){
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Hospital","root","v");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	@FXML
	private void existingPatient(){
		try{
		String PatientID = PatientExistingPatientID.getText();
		String contactNo = PatientExistingContactNo.getText();
		if(!PatientID.equals("")){
			PreparedStatement stmt=con.prepareStatement("select * from Patients where IDPatients=?");  
			stmt.setString(1, PatientID);
			ResultSet rs=stmt.executeQuery(); 
			if(rs.next()){
				System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6));
			}
		}
		else if (!contactNo.equals("")){
			PreparedStatement stmt=con.prepareStatement("select * from Patients where ContactNo=?");  
			stmt.setString(1, contactNo);
			ResultSet rs=stmt.executeQuery(); 
			if(rs.next()){
				System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6));
			}
		}
		
			
		//System.out.println(rs.getString(1)+"  "+rs.getString(2));  
		  
		//con.close();  
		  
		}catch(Exception e){ System.out.println(e);} 
	}
	
	@FXML
	private void appointmentsAvailable(){
		String Fname = AppointmentDoctorFname.getText();
		String LName = AppointmentDoctorLname.getText();
		String Speciality = AppointmentSpeciality.getText();
		String Time = AppointmentTime.getText();
		
		try {
			if(!Fname.equals("")){
				PreparedStatement stmt=con.prepareStatement("Select * From Doctor Where FirstName = ? and LastName=? and MaxAppointments>Appointments");
				stmt.setString(1,Fname);
				stmt.setString(2,LName);
				//1 specifies the first parameter in the query i.e. name
				ResultSet rs=stmt.executeQuery(); 
				if(rs.next()){
					System.out.println("Available");
					AppointmentAvailable.setText("Available");
				}
				else{
					AppointmentAvailable.setText("UnAvailable");

				}
				
			}
				    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			if(!Time.equals("")){
				PreparedStatement stmt=con.prepareStatement("Select * From Doctor Where  VisitingTime= ? and Department=? and MaxAppointments>Appointments");
				stmt.setString(1,Time);
				stmt.setString(2,Speciality);
				//1 specifies the first parameter in the query i.e. name
				ResultSet rs=stmt.executeQuery(); 
				if(rs.next()){
					System.out.println("Available");
					AppointmentAvailable.setText("Available");

				}
				else{
					AppointmentAvailable.setText("UnAvailable");
				}
			}
				    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML
	private void bookAppointment(){
		String DoctorID = AppointmentBookDoctorID.getText();
		try{
			PreparedStatement stmt=con.prepareStatement("update doctor set Appointments = Appointments + 1 where idDoctor = ?");  
			stmt.setString(1,DoctorID);//1 specifies the first parameter in the query i.e. name  
			 
			  
			int i=stmt.executeUpdate();  
		}catch(Exception e){ System.out.println(e);} 
	}
	
	@FXML
	private void cancelAppointment(){
		String DoctorID = AppointmentCancelDoctorID.getText();
		try{
			PreparedStatement stmt=con.prepareStatement("update doctor set Appointments = Appointments - 1 where idDoctor = ?");  
			stmt.setString(1,DoctorID);//1 specifies the first parameter in the query i.e. name   
			  
			int i=stmt.executeUpdate();  
		}catch(Exception e){ System.out.println(e);} 
	}
	
	@FXML
	private void AdmitAvailability(){
		String RoomType = AdmitAvailableRoomType.getText();
		
		try {
			if(!RoomType.equals("")){
				PreparedStatement stmt=con.prepareStatement("Select * From Room Where Capacity>Beds_available and RoomNo = ?");
				stmt.setString(1,RoomType);
				//1 specifies the first parameter in the query i.e. name
				ResultSet rs=stmt.executeQuery(); 
				if(rs.next()){
					System.out.println("Available");
					RoomAvailable.setText("Available");
				}
				else{
					RoomAvailable.setText("UnAvailable");

				}
				
			}
				    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML
	private void Admit(){
		String doctorID = AdmitFname.getText();
		String Speciality = AdmitSpeciality.getText();
		String RoomType = AdmitRoomType.getText();
		String  PatientID = AdmitPatientID.getText();
		String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		String DiseaseID = AdmitDiseaseID.getText();
		
		
		
		try {
			PreparedStatement stmt;
			stmt = con.prepareStatement("INSERT INTO `Hospital`.`Admissions` (`AdmitDate`, `DischargeDate`, `RoomNo`, `PatientID`,`DoctorID`,`D_ID`)values (?,?,?,?,?,?)");
			
			stmt.setString(1,date);
			stmt.setString(2,"");
			stmt.setString(3,RoomType);
			stmt.setString(4,PatientID);
			stmt.setString(5,doctorID);
			stmt.setString(6,DiseaseID);

			int i=stmt.executeUpdate(); 
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			PreparedStatement stmt;
			stmt = con.prepareStatement("Update Room set Beds_available = Beds_available -1 where RoomNo=?");
			stmt.setString(1,RoomType);
			int i=stmt.executeUpdate(); 
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML
	private void Discharge(){
		String dischargeID = DischargeAdmissionID.getText();
		String RoomType = null;
		String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		try{
			PreparedStatement stmt;
			stmt = con.prepareStatement("Select RoomNo from Admissions where AdmitNo = ?");
			stmt.setString(1,dischargeID);
			ResultSet rs=stmt.executeQuery(); 
			if(rs.next()){
				RoomType = rs.getString(1);
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			PreparedStatement stmt;
			stmt = con.prepareStatement("Update Room set Beds_available = Beds_available + 1 where RoomNo=?");
			stmt.setString(1,RoomType);
			int i=stmt.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			PreparedStatement stmt;
			stmt = con.prepareStatement("Update Admissions set DischargeDate = ? where AdmitNo=?");
			stmt.setString(1,date);
			stmt.setString(2,dischargeID);
			int i=stmt.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@FXML
	private void newPatient(){
		String fname =PatientNewFname.getText() ;
		String lname =PatientNewLname.getText() ;
		String DOB = PatientNewAddress.getText();
		String address = PatientNewDOB.getText();
		String contactNo = PatientNewContactNumber.getText();
		
		try{

			PreparedStatement stmt=con.prepareStatement("INSERT INTO `Hospital`.`Patients` (`FirstName`, `LastName`, `Address`, `ContactNo`,`DOB`) VALUES (?,?,?,?,?);");  
			stmt.setString(1, fname);
			stmt.setString(2, lname);
			stmt.setString(3, address);
			stmt.setString(4, contactNo);
			stmt.setString(5, DOB);

			int i=stmt.executeUpdate();
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
	
	
	
	@FXML
	private void deleteDoctor(){
		String DoctorID = DeleteDoctorID.getText();
		PreparedStatement stmt;
		try {
			stmt = con.prepareStatement("delete from Doctor where idDoctor =?");
			stmt.setString(1,DoctorID);  
			  
			int i=stmt.executeUpdate();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
	}
	
	@FXML 
	private void diseaseEnquiry(){
		String diseaseID = DiagnosisDisease.getText();
		
		try
		{PreparedStatement stmt=con.prepareStatement("select * from Diseases where idDiseases = ?");  
		stmt.setString(1, diseaseID);
		ResultSet rs=stmt.executeQuery(); 
		if(rs.next()){
			Diagnosis.setText(rs.getString(2)+ "  "+rs.getString(3)+ "  "+ rs.getString(4) );
		}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	@FXML 
	private void patientEnquiry(){
		String patientID = EnquiryPatientID.getText();
		String data = "";
		try
		{PreparedStatement stmt=con.prepareStatement("select DiseasesName, FirstName from Admissions,Patients,Diseases where PatientID=idPatients and D_ID = idDiseases and PatientID = ?");  
		stmt.setString(1,patientID);
		ResultSet rs=stmt.executeQuery(); 
		while(rs.next()){
			data = data + " " +rs.getString(1);
			
		}
		EnquiryLabel.setText(data);
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}

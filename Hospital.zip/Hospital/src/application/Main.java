package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import java.io.IOException;
import java.sql.*;  



public class Main extends Application {
	private Stage primaryStage;
	private BorderPane rootlayout;
	
	
	
	@Override
	public void start(Stage primaryStage) {
		this.primaryStage=primaryStage;
		this.primaryStage.setTitle("NFCFC Hospital");
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("RootLayout.fxml"));
			rootlayout = (BorderPane)loader.load();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		Scene scene= new Scene(rootlayout);
		primaryStage.setScene(scene);
		primaryStage.show();
		login();
	}
	
	
	
	public void login(){
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("LoginRoot.fxml"));
			rootlayout = (BorderPane)loader.load();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		Scene scene= new Scene(rootlayout);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("Login.fxml"));
			AnchorPane filterlayout = (AnchorPane)loader.load();
			LoginControl controller = loader.getController();
			controller.control(this);
			rootlayout.setCenter(filterlayout);
			
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void welcome(){
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("RootLayout.fxml"));
			rootlayout = (BorderPane)loader.load();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		Scene scene= new Scene(rootlayout);
		primaryStage.setScene(scene);
		primaryStage.show();
		
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("Welcome.fxml"));
			AnchorPane filterlayout = (AnchorPane)loader.load();
			//LoginControl controller = loader.getController();
			//controller.control(this);
			rootlayout.setCenter(filterlayout);
			
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) { 
		launch(args);
	}
}
